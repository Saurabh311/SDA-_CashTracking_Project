package Shapes;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        Funct startRun = new Funct();
        startRun.startApp();
    }
}
