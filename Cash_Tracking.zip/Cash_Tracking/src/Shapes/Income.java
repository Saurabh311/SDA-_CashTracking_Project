package Shapes;

public class Income extends Transactions {
    public Income (int month, int amount){
        setMonth(month);
        setAmount(amount);
        setTittle("Income");

    }

}
